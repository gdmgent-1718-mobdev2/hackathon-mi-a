import React, { Component } from 'react';
import { StyleSheet, View, Text } from 'react-native';
import LoginForm from './loginForm';


export default class Login  extends Component{
  render(){
    return(
    <View style={styles.container}>
    
    {/* <Text style={styles.title}>test login</Text> */}
      <View style={styles.formContainer}>
        {/* inhoud form */}
        <Text style={styles.title}>Login / Register</Text>
        <LoginForm> </LoginForm>
      </View>
     
    </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex:1,
    backgroundColor:  '#003399',
  },
  title: {
   fontSize: 30,
   color: '#006633',
   marginTop: 50,
   textAlign: 'center',
   opacity: 0.8,

  }

});