import React, { Component } from 'react';
import { View, Text  } from 'react-native';

class LogoMidden extends Component {
  render() {
    return (
      <View>
       
      </View>
    );
  }
}

export default componentName;
