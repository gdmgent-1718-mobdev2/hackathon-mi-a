import React, { Component } from 'react';
import { StyleSheet, View, TextInput, Text, TouchableOpacity, KeyboardAvoidingView, StatusBar } from 'react-native';

export default class LoginForm extends Component{
  render(){
    return(
      <KeyboardAvoidingView behavior="padding" style={styles.container}>
      {/* <StatusBar barStyle = "light-content"/> 
        <Text>Titel loginform</Text>*/}
        {/* text input email */}
        <TextInput 
            placeholder = "Email"
            placeholderTextColor="#000066"
            returnKeyType="next"
            onSubmitEditing={()=>this.passwordInput.focus()}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}

            style={styles.input}
            />
            {/* text input password */}          
            <TextInput 
            placeholder = "password"
            placeholderTextColor="#000066"
            returnKeyType="go"
            secureTextEntry
            style={styles.input}
            ref={(input) => this.passwordInput = input}
            />

            <TouchableOpacity style={styles.buttoncontainer}>
              <Text  style={styles.buttontext}>Login</Text>
            </TouchableOpacity>
      </KeyboardAvoidingView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    padding: 20
  },
  input: {
    height: 50,
    backgroundColor: '#00cc66',
    marginBottom: 10,
    paddingHorizontal: 10,
    borderRadius: 10,
  },
  buttoncontainer: {
    backgroundColor: "#660000",
    paddingVertical: 10,
    borderRadius: 10,
  },
  buttontext: {
    textAlign: 'center',
    color: '#FFF',
    fontWeight: '700'
  }
});