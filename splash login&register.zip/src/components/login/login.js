import React, { Component } from 'react';
import { StyleSheet, View, Text, ScrollView } from 'react-native';
import LoginForm from './loginForm';
import RegisterForm from './registerform';
import LogoMidden from '../Logo/logoMidden';

export default class Login  extends Component{
  render(){
    return(
  <ScrollView>
    <View style={styles.container}>
    <LogoMidden style={styles.containerLogo}/>
    {/* <Text style={styles.title}>test login</Text> */}
   
      <View style={styles.formContainer}>
        {/* inhoud form */}
        <Text style={styles.title}>Login</Text>
        <LoginForm> </LoginForm>
        </View>

        <View style={styles.formContainer} style={styles.formContainer2}>
        <Text style={styles.title}>Register</Text>
        <RegisterForm/>
        </View>
       
    </View>

   </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  title: {
   fontSize: 30,
   color: '#006633',
   marginTop: 50,
   textAlign: 'center',
   opacity: 0.8,

  },
  formContainer: {
    height: 250
  },
  formContainer2: {
    marginTop : 30
  },
  containerLogo:{
    height: 100
  }

});