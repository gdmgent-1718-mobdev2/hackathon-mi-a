import React, { Component } from 'react';
import { StyleSheet, View, TextInput, Text, TouchableOpacity, KeyboardAvoidingView, StatusBar } from 'react-native';

export default class RegisterForm extends Component{
  render(){
    return(
      <KeyboardAvoidingView behavior="padding" style={styles.container}>
      {/* <StatusBar barStyle = "light-content"/> 
        <Text>Titel loginform</Text>*/}
        {/* text input gebruikersnaam */}
        <TextInput 
            placeholder = "Gebruikersnaam"
            placeholderTextColor="#000066"
            returnKeyType="next"
            autoCapitalize="none"
            autoCorrect={false}
            style={styles.input}
            onSubmitEditing={()=>this.passwordInput.focus()}
            />
            {/* text input password */}          
            <TextInput 
            placeholder = "Wachtwoord"
            placeholderTextColor="#000066"
            returnKeyType="next"
            secureTextEntry
            style={styles.input}
            onSubmitEditing={()=>this.confirmPasswordInput.focus()}
            ref={(input) => this.passwordInput = input}
            />
            {/* text input password */}          
            <TextInput 
            placeholder = "Bevestig wachtwoord"
            placeholderTextColor="#000066"
            returnKeyType="next"
            secureTextEntry
            style={styles.input}
            onSubmitEditing={()=>this.emailInput.focus()}
            ref={(input) => this.confirmPasswordInput = input}
            />
             {/* text input email */}
        <TextInput 
            placeholder = "Email"
            placeholderTextColor="#000066"
            returnKeyType="go"
            keyboardType= "email-address"
            autoCapitalize="none"
            autoCorrect={false}
            style={styles.input}
            ref={(input) => this.emailInput = input}
            />

            <TouchableOpacity style={styles.buttoncontainer}>
              <Text  style={styles.buttontext}>Register</Text>
            </TouchableOpacity>
      </KeyboardAvoidingView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    padding: 20
  },
  input: {
    height: 50,
    backgroundColor: '#00cc66',
    marginBottom: 10,
    paddingHorizontal: 10,
    borderRadius: 10,
  },
  buttoncontainer: {
    backgroundColor: "#660000",
    paddingVertical: 10,
    borderRadius: 10,
  },
  buttontext: {
    textAlign: 'center',
    color: '#FFF',
    fontWeight: '700'
  }
});