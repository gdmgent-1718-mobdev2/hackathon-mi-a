import React, { Component } from 'react';
import { StyleSheet, View, TextInput, Text, TouchableOpacity } from 'react-native';

export default class LoginForm extends Component{
  render(){
    return(
      <View style={styles.container}>
      <Text>Titel loginform</Text>
          {/* text input email */}
          <TextInput 
          placeholder = "Email"
          placeholderTextColor="#000066"
          style={styles.input}
          />
          {/* text input password */}          
          <TextInput 
          placeholder = "password"
          placeholderTextColor="#000066"
          secureTextEntry = 'true'
          style={styles.input}/>

          <TouchableOpacity style={styles.buttoncontainer}>
            <Text  style={styles.button}>Login</Text>
          </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    padding: 20
  },
  input: {
    height: 50,
    width: 300,
    backgroundColor: '#00cc66',
    marginBottom: 10,
    paddingHorizontal: 10
  },
  buttoncontainer: {
    backgroundColor: "#660000",
    paddingVertical: 10
  },
  button: {
    textAlign: 'center',
    color: '#FFF',
    fontWeight: '700'
  }
});